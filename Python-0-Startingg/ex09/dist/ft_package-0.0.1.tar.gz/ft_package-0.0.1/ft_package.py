def count_in_list(lst, item):
	count = 0
	for i in lst:
		if i == item:
			count += 1
	return count